# botwasapv3
Add feature level
Add feature register
add hight level for use feature
(Comming soon)
